  
  <footer class="main-footer">

  </footer>

  <script src="../javascript/jQuery.js"></script>
  <script src="../javascript/funciones.js"></script>
  <script src="../javascript/jQueryUI.js"></script>
</body>
</html>