<main class="public-home">
  <div class="container">
    <h1> Welcome to Nemo </h1>
    <p> Organize your ideas </p>
  </div>
</main>